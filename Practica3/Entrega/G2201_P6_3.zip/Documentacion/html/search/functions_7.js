var searchData=
[
  ['readfile',['readFile',['../Ejercicio4_8c.html#a6c5067d39455dbcbf23790f3092d2444',1,'Ejercicio4.c']]]
];
