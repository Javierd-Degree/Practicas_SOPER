var searchData=
[
  ['matriz',['matriz',['../Ejercicio13_8c.html#ac63a9b0c7cf4cdbaba641e8f59c29a51',1,'matriz():&#160;Ejercicio13.c'],['../Ejercicio13b_8c.html#ac63a9b0c7cf4cdbaba641e8f59c29a51',1,'matriz():&#160;Ejercicio13b.c']]],
  ['multiplicacion',['multiplicacion',['../Ejercicio13_8c.html#ad1b3bf648d6b4a06bc703025cce83b58',1,'multiplicacion():&#160;Ejercicio13.c'],['../Ejercicio13b_8c.html#ad1b3bf648d6b4a06bc703025cce83b58',1,'multiplicacion():&#160;Ejercicio13b.c']]]
];
