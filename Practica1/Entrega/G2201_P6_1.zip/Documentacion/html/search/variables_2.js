var searchData=
[
  ['num',['num',['../struct__estructura.html#a2642fb68e71de28dc0c6945fb1c620bb',1,'_estructura']]]
];
