var searchData=
[
  ['borrar_5fsemaforo',['Borrar_Semaforo',['../LibreriaSemaforos_8c.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;LibreriaSemaforos.c'],['../LibreriaSemaforos_8h.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;LibreriaSemaforos.c']]]
];
