var searchData=
[
  ['num_5fproc',['NUM_PROC',['../Ejercicio4_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4.c'],['../Ejercicio5a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio5a.c'],['../Ejercicio5b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio5b.c']]]
];
