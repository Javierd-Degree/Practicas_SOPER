var indexSectionsWithContent =
{
  0: "abcdeimnrstu",
  1: "s",
  2: "e",
  3: "abcdimrtu",
  4: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros"
};

