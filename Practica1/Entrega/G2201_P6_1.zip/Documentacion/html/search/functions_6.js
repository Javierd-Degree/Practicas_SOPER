var searchData=
[
  ['potencia',['potencia',['../Ejercicio9_8c.html#a1e86e884e71a85fdafe94dc3ee7f77f8',1,'Ejercicio9.c']]]
];
