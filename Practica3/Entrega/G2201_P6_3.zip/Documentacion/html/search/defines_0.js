var searchData=
[
  ['num_5fhijos',['NUM_HIJOS',['../Ejercicio2_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'NUM_HIJOS():&#160;Ejercicio2.c'],['../Ejercicio2__solved_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'NUM_HIJOS():&#160;Ejercicio2_solved.c']]]
];
