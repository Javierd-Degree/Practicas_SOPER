var searchData=
[
  ['numcombinatorio',['numCombinatorio',['../Ejercicio9_8c.html#ab13db5a54377e7e55eb6db91185af27e',1,'Ejercicio9.c']]]
];
