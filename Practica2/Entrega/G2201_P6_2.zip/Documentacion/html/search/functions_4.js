var searchData=
[
  ['inicializar_5fsemaforo',['Inicializar_Semaforo',['../Ejercicio8_8c.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;Ejercicio8.c'],['../Ejercicio8_8h.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;Ejercicio8.c']]]
];
