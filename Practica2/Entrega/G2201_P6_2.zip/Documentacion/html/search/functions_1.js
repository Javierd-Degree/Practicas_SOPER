var searchData=
[
  ['borrar_5fsemaforo',['Borrar_Semaforo',['../Ejercicio8_8c.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;Ejercicio8.c'],['../Ejercicio8_8h.html#a731339337960a681efa435a10f12c312',1,'Borrar_Semaforo(int semid):&#160;Ejercicio8.c']]]
];
