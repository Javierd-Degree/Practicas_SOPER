var indexSectionsWithContent =
{
  0: "_ceflmnps",
  1: "_",
  2: "e",
  3: "ceflmnps",
  4: "cmnps",
  5: "em",
  6: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

