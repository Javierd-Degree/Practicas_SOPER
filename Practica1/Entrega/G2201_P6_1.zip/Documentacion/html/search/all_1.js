var searchData=
[
  ['cad',['cad',['../struct__estructura.html#af8575f769a43e1d92db4056c93ffd50e',1,'_estructura']]],
  ['calcular_5fprimos',['calcular_primos',['../Ejercicio12a_8c.html#af47ddf18fdd009c7039d7ec241f4d4e5',1,'calcular_primos(void *arg):&#160;Ejercicio12a.c'],['../Ejercicio12b_8c.html#af47ddf18fdd009c7039d7ec241f4d4e5',1,'calcular_primos(void *arg):&#160;Ejercicio12b.c']]]
];
