var searchData=
[
  ['num',['num',['../struct__estructura.html#a2642fb68e71de28dc0c6945fb1c620bb',1,'_estructura']]],
  ['num_5fproc',['NUM_PROC',['../Ejercicio4_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio4.c'],['../Ejercicio5a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio5a.c'],['../Ejercicio5b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;Ejercicio5b.c']]],
  ['numcombinatorio',['numCombinatorio',['../Ejercicio9_8c.html#ab13db5a54377e7e55eb6db91185af27e',1,'Ejercicio9.c']]]
];
