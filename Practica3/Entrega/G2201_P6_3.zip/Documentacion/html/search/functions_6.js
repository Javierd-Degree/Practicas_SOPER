var searchData=
[
  ['produce_5fitem',['produce_item',['../Ejercicio3_8c.html#af6be62fb8af1ca164fa2861c403b8245',1,'Ejercicio3.c']]]
];
