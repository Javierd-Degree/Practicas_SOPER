var searchData=
[
  ['es_5fprimo',['es_primo',['../Ejercicio12a_8c.html#ae09682ef27c72bab20d8ab298c7b090f',1,'es_primo(int n):&#160;Ejercicio12a.c'],['../Ejercicio12b_8c.html#ae09682ef27c72bab20d8ab298c7b090f',1,'es_primo(int n):&#160;Ejercicio12b.c']]]
];
