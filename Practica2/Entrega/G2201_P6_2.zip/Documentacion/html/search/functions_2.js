var searchData=
[
  ['captura',['captura',['../Ejercicio4_8c.html#a0897883a0dfdf1023f377e262cee1299',1,'Ejercicio4.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../Ejercicio8_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;Ejercicio8.c'],['../Ejercicio8_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;Ejercicio8.c']]]
];
