var indexSectionsWithContent =
{
  0: "_abcdeilmnprstuw",
  1: "_is",
  2: "el",
  3: "abcdimprtuw",
  4: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros"
};

