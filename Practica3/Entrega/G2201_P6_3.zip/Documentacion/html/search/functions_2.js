var searchData=
[
  ['captura',['captura',['../Ejercicio2_8c.html#a0897883a0dfdf1023f377e262cee1299',1,'captura():&#160;Ejercicio2.c'],['../Ejercicio2__solved_8c.html#a0897883a0dfdf1023f377e262cee1299',1,'captura():&#160;Ejercicio2_solved.c']]],
  ['consume_5fitem',['consume_item',['../Ejercicio3_8c.html#a8a453d70ebc614f358646af9dcf7cd49',1,'Ejercicio3.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../LibreriaSemaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;LibreriaSemaforos.c'],['../LibreriaSemaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;LibreriaSemaforos.c']]]
];
