var searchData=
[
  ['pos2',['pos2',['../Ejercicio13b_8c.html#a1b3a85917a11704027ecd416ffa736fc',1,'Ejercicio13b.c']]],
  ['potencia',['potencia',['../Ejercicio9_8c.html#a1e86e884e71a85fdafe94dc3ee7f77f8',1,'Ejercicio9.c']]]
];
