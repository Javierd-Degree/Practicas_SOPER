var searchData=
[
  ['num_5fhijos',['NUM_HIJOS',['../Ejercicio4_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'Ejercicio4.c']]]
];
