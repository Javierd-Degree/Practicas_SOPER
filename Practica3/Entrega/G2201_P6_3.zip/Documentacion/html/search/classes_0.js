var searchData=
[
  ['_5fmessage',['_message',['../struct__message.html',1,'']]]
];
